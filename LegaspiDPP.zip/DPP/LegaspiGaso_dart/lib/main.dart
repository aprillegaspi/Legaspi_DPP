import 'dart:io';

void main() {
  double p1 = 45.75;
  double p2 = 43.18;
  double p3 = 37.12;
  double p4 = 48.03;

  print('Type of Payment');
  var n = stdin.readLineSync();
  if (n == 'cash') {
    print('Type of Fuel');
    var e = stdin.readLineSync();
    if (e == 'leaded') {
      print('Input Amount: ');
      var g = int.parse(stdin.readLineSync());
      var sum = g / p1;

      print('$sum Liter Of Leaded Gasoline');
      print('Thank you');
    } else if (e == 'unleaded') {
      print('Input Amount: ');
      var g = int.parse(stdin.readLineSync());
      var sum = g * p2;
      print('$sum Liter Of Unleaded Gasoline');
      print('Thank you');
    } else if (e == 'diesel') {
      print('Input Amount: ');
      var g = int.parse(stdin.readLineSync());
      var sum = g / p3;
      print('$sum Liter Of Diesel Gasoline');
      print('Thank you');
    } else if (e == 'biodiesel') {
      print('Input Amount: ');
      var g = int.parse(stdin.readLineSync());
      var sum = g / p4;
      print('$sum Liter Of BioDiesel Gasoline');
      print('Thank you');
    } else {
      print('No Transaction');
    }
  } else if (n == 'liters') {
    if (n == 'liters') {
      print('Type of Fuel');
      var e = stdin.readLineSync();
      if (e == 'leaded') {
        print('Input How many Liters: ');
        var g = int.parse(stdin.readLineSync());
        var sum = g * p1;
        print('Total Cash Amount:$sum');
        print('Thank you');
      } else if (e == 'unleaded') {
        print('Input How many Liters: ');
        var g = int.parse(stdin.readLineSync());
        var sum = g * p2;
        print('Total Cash Amount:$sum');
        print('Thank you');
      } else if (e == 'diesel') {
        print('Input How many Liters: ');
        var g = int.parse(stdin.readLineSync());
        var sum = g * p3;
        print('Total Cash Amount:$sum');
        print('Thank you');
      } else if (e == 'biodiesel') {
        print('Input How many Liters ');
        var g = int.parse(stdin.readLineSync());
        var sum = g * p4;
        print('Total Cash Amount:$sum');
        print('Thank you!');
      } else {
        print('No Transaction');
      }
    }
  } else {
    print('No Transaction');
  }
}
